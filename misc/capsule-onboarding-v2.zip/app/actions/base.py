from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any


@dataclass
class ActionResult:
    ok: bool
    message: str
    meta: dict[str, Any] | None = None


class BaseAction(ABC):
    key: str

    @abstractmethod
    def idempotency_key(self, payload: dict) -> str:
        ...

    @abstractmethod
    def run(self, payload: dict) -> ActionResult:
        ...

import subprocess
from app.actions.base import BaseAction, ActionResult
from app.settings import settings


class LocalRunShell(BaseAction):
    key = "local.run_shell"

    def idempotency_key(self, payload: dict) -> str:
        stable = payload.get("stable_key")
        if stable:
            return f"{self.key}:{stable}"
        return f"{self.key}:{hash(payload.get('command',''))}"

    def run(self, payload: dict) -> ActionResult:
        cmd = payload.get("command")
        if not cmd:
            return ActionResult(ok=False, message="Missing command")

        try:
            proc = subprocess.run(
                cmd,
                shell=True,
                capture_output=True,
                text=True,
                timeout=settings.LOCAL_SCRIPT_TIMEOUT_SEC,
            )
            meta = {
                "returncode": proc.returncode,
                "stdout": (proc.stdout or "")[-4000:],
                "stderr": (proc.stderr or "")[-4000:],
            }
            if proc.returncode == 0:
                return ActionResult(ok=True, message="Command executed", meta=meta)
            return ActionResult(ok=False, message="Command failed", meta=meta)
        except Exception as e:
            return ActionResult(ok=False, message=f"Exception: {e}")

from app.actions.local_script import LocalRunShell
from app.actions.base import BaseAction

_REGISTRY: dict[str, BaseAction] = {
    LocalRunShell.key: LocalRunShell(),
}


def get_runner(action_key: str) -> BaseAction:
    if action_key not in _REGISTRY:
        raise ValueError(f"Unknown action_key: {action_key}")
    return _REGISTRY[action_key]


def list_actions() -> list[str]:
    return sorted(_REGISTRY.keys())

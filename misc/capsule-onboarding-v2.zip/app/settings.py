from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    APP_NAME: str = "Capsule Onboarding"
    ENV: str = "dev"
    SECRET_KEY: str = "change_me"

    DATABASE_URL: str
    REDIS_URL: str

    PUBLIC_BASE_URL: str = "http://localhost:8088"

    OIDC_ISSUER_URL: str
    OIDC_CLIENT_ID: str
    OIDC_CLIENT_SECRET: str
    OIDC_ALLOWED_GROUPS: str = ""

    LOCAL_SCRIPT_TIMEOUT_SEC: int = 120

    CELERY_BROKER_URL: str
    CELERY_RESULT_BACKEND: str

    class Config:
        env_file = ".env"
        extra = "ignore"


settings = Settings()

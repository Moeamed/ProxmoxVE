from sqlalchemy.orm import Session
from app.models.hire import Hire
from app.models.task import Task
from app.services.templates import get_tasks_for_team
from app.services.audit_service import log_event


def create_hire_with_template_tasks(db: Session, hire: Hire, actor: str) -> Hire:
    db.add(hire)
    db.commit()
    db.refresh(hire)

    for t in get_tasks_for_team(hire.team):
        db.add(Task(
            hire_id=hire.id,
            title=t["title"],
            owner=t.get("owner", "IT"),
            status="TODO",
        ))
    db.commit()

    log_event(db, actor=actor, event="HIRE_CREATED", target_type="hire", target_id=hire.id, meta={"team": hire.team})
    return hire

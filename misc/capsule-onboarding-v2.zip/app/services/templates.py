TASK_TEMPLATES = {
    "FX": [
        {"title": "Créer compte Slack", "owner": "IT"},
        {"title": "Créer compte Google Workspace", "owner": "IT"},
        {"title": "Créer accès NAS + home folder", "owner": "IT"},
        {"title": "Créer compte Ftrack (role FX)", "owner": "IT"},
        {"title": "Welcome + buddy intro", "owner": "MANAGER"},
    ],
    "ANIM": [
        {"title": "Créer compte Slack", "owner": "IT"},
        {"title": "Créer compte Google Workspace", "owner": "IT"},
        {"title": "Créer accès NAS + home folder", "owner": "IT"},
        {"title": "Créer compte Ftrack (role ANIM)", "owner": "IT"},
        {"title": "Welcome + buddy intro", "owner": "MANAGER"},
    ],
    "PROD": [
        {"title": "Créer compte Slack", "owner": "IT"},
        {"title": "Créer compte Google Workspace", "owner": "IT"},
        {"title": "Créer compte Ftrack (role PROD)", "owner": "IT"},
        {"title": "Welcome + accès pages management", "owner": "MANAGER"},
    ],
}

DEFAULT_TEMPLATE = [
    {"title": "Créer compte Slack", "owner": "IT"},
    {"title": "Créer compte Google Workspace", "owner": "IT"},
    {"title": "Créer accès NAS + home folder", "owner": "IT"},
    {"title": "Welcome + buddy intro", "owner": "MANAGER"},
]


def get_tasks_for_team(team: str) -> list[dict]:
    team = (team or "").upper().strip()
    return TASK_TEMPLATES.get(team, DEFAULT_TEMPLATE)

import json
from sqlalchemy.orm import Session
from app.models.audit import AuditLog


def log_event(
    db: Session,
    actor: str,
    event: str,
    target_type: str | None = None,
    target_id: int | None = None,
    meta: dict | None = None,
) -> None:
    row = AuditLog(
        actor=actor,
        event=event,
        target_type=target_type,
        target_id=target_id,
        meta_json=json.dumps(meta or {}, ensure_ascii=False),
    )
    db.add(row)
    db.commit()

from fastapi import Depends, HTTPException
from sqlalchemy.orm import Session
from starlette.requests import Request

from app.database import SessionLocal
from app.security import get_user_from_session, user_has_access


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_current_user(request: Request) -> dict:
    user = get_user_from_session(request)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    if not user_has_access(user):
        raise HTTPException(status_code=403, detail="Access denied")
    return user

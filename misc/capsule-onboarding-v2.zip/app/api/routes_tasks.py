from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps import get_db, get_current_user
from app.models.task import Task
from app.schemas.task import TaskCreate, TaskUpdate

router = APIRouter(prefix="/api/tasks", tags=["tasks"])


@router.get("")
def list_tasks(hire_id: int | None = None, db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    q = db.query(Task)
    if hire_id is not None:
        q = q.filter(Task.hire_id == hire_id)
    return q.order_by(Task.id.desc()).all()


@router.post("")
def create_task(payload: TaskCreate, db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    t = Task(**payload.model_dump())
    db.add(t)
    db.commit()
    db.refresh(t)
    return t


@router.patch("/{task_id}")
def update_task(task_id: int, payload: TaskUpdate, db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    t = db.get(Task, task_id)
    for k, v in payload.model_dump(exclude_unset=True).items():
        setattr(t, k, v)
    db.add(t)
    db.commit()
    db.refresh(t)
    return t

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps import get_db, get_current_user
from app.models.hire import Hire
from app.schemas.hire import HireCreate, HireOut, HireUpdate
from app.services.onboarding_service import create_hire_with_template_tasks

router = APIRouter(prefix="/api/hires", tags=["hires"])


@router.get("", response_model=list[HireOut])
def list_hires(db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    return db.query(Hire).order_by(Hire.id.desc()).all()


@router.post("", response_model=HireOut)
def create_hire(payload: HireCreate, db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    hire = Hire(**payload.model_dump())
    actor = user.get("email") or user.get("name") or "unknown"
    return create_hire_with_template_tasks(db, hire, actor)


@router.patch("/{hire_id}", response_model=HireOut)
def update_hire(hire_id: int, payload: HireUpdate, db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    hire = db.get(Hire, hire_id)
    for k, v in payload.model_dump(exclude_unset=True).items():
        setattr(hire, k, v)
    db.add(hire)
    db.commit()
    db.refresh(hire)
    return hire

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps import get_db, get_current_user
from app.models.action import ActionInstance
from app.schemas.action import ActionCreate
from app.workers.tasks import run_action

router = APIRouter(prefix="/api/actions", tags=["actions"])


@router.get("")
def list_actions(hire_id: int | None = None, db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    q = db.query(ActionInstance)
    if hire_id is not None:
        q = q.filter(ActionInstance.hire_id == hire_id)
    return q.order_by(ActionInstance.id.desc()).all()


@router.post("")
def create_action(payload: ActionCreate, db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    actor = user.get("email") or user.get("name") or "unknown"

    a = ActionInstance(
        hire_id=payload.hire_id,
        action_key=payload.action_key,
        payload=payload.payload,
        triggered_by=actor,
        status="QUEUED",
    )
    db.add(a)
    db.commit()
    db.refresh(a)

    run_action.delay(a.id)
    return a


@router.post("/{action_id}/rerun")
def rerun_action(action_id: int, db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    a = db.get(ActionInstance, action_id)
    a.status = "QUEUED"
    db.add(a)
    db.commit()
    run_action.delay(a.id)
    return {"ok": True, "action_id": a.id}

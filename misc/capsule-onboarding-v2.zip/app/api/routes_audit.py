from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps import get_db, get_current_user
from app.models.audit import AuditLog

router = APIRouter(prefix="/api/audit", tags=["audit"])


@router.get("")
def list_audit(db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    return db.query(AuditLog).order_by(AuditLog.id.desc()).limit(200).all()

from datetime import date
from pydantic import BaseModel


class TaskCreate(BaseModel):
    hire_id: int
    title: str
    description: str | None = None
    owner: str = "IT"
    status: str = "TODO"
    due_date: date | None = None
    notes: str | None = None


class TaskUpdate(BaseModel):
    title: str | None = None
    description: str | None = None
    owner: str | None = None
    status: str | None = None
    due_date: date | None = None
    notes: str | None = None

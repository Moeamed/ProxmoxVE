from datetime import date
from pydantic import BaseModel


class HireCreate(BaseModel):
    full_name: str
    personal_email: str | None = None
    team: str = "UNKNOWN"
    role: str = "UNKNOWN"
    start_date: date
    manager_name: str | None = None
    buddy_name: str | None = None


class HireUpdate(BaseModel):
    full_name: str | None = None
    personal_email: str | None = None
    team: str | None = None
    role: str | None = None
    status: str | None = None
    manager_name: str | None = None
    buddy_name: str | None = None


class HireOut(BaseModel):
    id: int
    full_name: str
    personal_email: str | None
    team: str
    role: str
    start_date: date
    status: str
    manager_name: str | None
    buddy_name: str | None

    class Config:
        from_attributes = True

from pydantic import BaseModel


class ActionCreate(BaseModel):
    hire_id: int
    action_key: str
    payload: dict


class ActionUpdate(BaseModel):
    status: str | None = None
    retry_count: int | None = None

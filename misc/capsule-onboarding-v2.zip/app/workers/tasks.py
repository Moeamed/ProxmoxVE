import json
from datetime import datetime

from celery import shared_task
from sqlalchemy import select

from app.database import SessionLocal
from app.models.action import ActionInstance
from app.models.enums import ActionStatus
from app.actions.registry import get_runner
from app.services.audit_service import log_event


@shared_task(bind=True, max_retries=3, default_retry_delay=20)
def run_action(self, action_id: int):
    db = SessionLocal()
    try:
        action = db.get(ActionInstance, action_id)
        if not action:
            return

        if action.status in (ActionStatus.SUCCESS.value, ActionStatus.SKIPPED.value):
            return

        runner = get_runner(action.action_key)
        idem_key = runner.idempotency_key(action.payload)
        action.idempotency_key = idem_key

        stmt = select(ActionInstance).where(
            ActionInstance.idempotency_key == idem_key,
            ActionInstance.status == ActionStatus.SUCCESS.value,
        )
        already = db.execute(stmt).scalars().first()
        if already:
            action.status = ActionStatus.SKIPPED.value
            action.result_log = json.dumps({"ok": True, "message": "Already executed successfully"}, ensure_ascii=False)
            db.commit()
            return

        action.status = ActionStatus.RUNNING.value
        action.started_at = datetime.utcnow()
        db.commit()

        result = runner.run(action.payload)

        action.finished_at = datetime.utcnow()
        action.result_log = json.dumps({"ok": result.ok, "message": result.message, "meta": result.meta}, ensure_ascii=False)

        if result.ok:
            action.status = ActionStatus.SUCCESS.value
        else:
            action.status = ActionStatus.FAILED.value

        db.commit()

        log_event(db, actor=action.triggered_by or "system", event="ACTION_FINISHED", target_type="action", target_id=action.id)

        if not result.ok:
            action.retry_count += 1
            db.commit()
            raise Exception(result.message)

    except Exception as e:
        db.rollback()
        raise self.retry(exc=e)
    finally:
        db.close()

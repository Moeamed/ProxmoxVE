import enum


class HireStatus(str, enum.Enum):
    PREBOARDING = "PREBOARDING"
    ONBOARDING = "ONBOARDING"
    DONE = "DONE"


class TaskStatus(str, enum.Enum):
    TODO = "TODO"
    DOING = "DOING"
    DONE = "DONE"
    BLOCKED = "BLOCKED"


class ActionStatus(str, enum.Enum):
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"

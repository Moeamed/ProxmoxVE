from datetime import datetime
from sqlalchemy import String, DateTime, Integer, ForeignKey, JSON, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base
from app.models.enums import ActionStatus


class ActionInstance(Base):
    __tablename__ = "actions"

    id: Mapped[int] = mapped_column(primary_key=True)
    hire_id: Mapped[int] = mapped_column(Integer, ForeignKey("hires.id"), index=True, nullable=False)

    action_key: Mapped[str] = mapped_column(String(128), nullable=False)
    payload: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)

    status: Mapped[str] = mapped_column(String(32), default=ActionStatus.QUEUED.value)
    idempotency_key: Mapped[str | None] = mapped_column(String(256), nullable=True, index=True)

    triggered_by: Mapped[str | None] = mapped_column(String(200), nullable=True)

    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    result_log: Mapped[str | None] = mapped_column(Text, nullable=True)
    retry_count: Mapped[int] = mapped_column(Integer, default=0)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

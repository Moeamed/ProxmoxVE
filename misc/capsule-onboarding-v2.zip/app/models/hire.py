from datetime import date, datetime
from sqlalchemy import String, Date, DateTime
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base
from app.models.enums import HireStatus


class Hire(Base):
    __tablename__ = "hires"

    id: Mapped[int] = mapped_column(primary_key=True)
    full_name: Mapped[str] = mapped_column(String(200), nullable=False)
    personal_email: Mapped[str | None] = mapped_column(String(200), nullable=True)

    team: Mapped[str] = mapped_column(String(64), default="UNKNOWN")
    role: Mapped[str] = mapped_column(String(64), default="UNKNOWN")

    start_date: Mapped[date] = mapped_column(Date, nullable=False)
    status: Mapped[str] = mapped_column(String(32), default=HireStatus.PREBOARDING.value)

    manager_name: Mapped[str | None] = mapped_column(String(200), nullable=True)
    buddy_name: Mapped[str | None] = mapped_column(String(200), nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

from fastapi import FastAPI
from starlette.middleware.sessions import SessionMiddleware
from starlette.responses import RedirectResponse
from starlette.requests import Request

from authlib.integrations.starlette_client import OAuth

from app.settings import settings
from app.api.routes_hires import router as hires_router
from app.api.routes_tasks import router as tasks_router
from app.api.routes_actions import router as actions_router
from app.api.routes_audit import router as audit_router

from app.ui import build_ui

app = FastAPI(title=settings.APP_NAME)

app.add_middleware(SessionMiddleware, secret_key=settings.SECRET_KEY)

app.include_router(hires_router)
app.include_router(tasks_router)
app.include_router(actions_router)
app.include_router(audit_router)

oauth = OAuth()
oauth.register(
    name="authentik",
    client_id=settings.OIDC_CLIENT_ID,
    client_secret=settings.OIDC_CLIENT_SECRET,
    server_metadata_url=f"{settings.OIDC_ISSUER_URL}/.well-known/openid-configuration",
    client_kwargs={"scope": "openid email profile"},
)

@app.get("/auth/login")
async def login(request: Request):
    redirect_uri = f"{settings.PUBLIC_BASE_URL}/auth/callback"
    return await oauth.authentik.authorize_redirect(request, redirect_uri)

@app.get("/auth/callback")
async def auth_callback(request: Request):
    token = await oauth.authentik.authorize_access_token(request)
    userinfo = token.get("userinfo") or {}
    groups = userinfo.get("groups", [])

    request.session["user"] = {
        "name": userinfo.get("name") or userinfo.get("preferred_username") or "unknown",
        "email": userinfo.get("email"),
        "groups": groups,
        "raw": userinfo,
    }
    return RedirectResponse(url="/")

@app.get("/auth/logout")
async def logout(request: Request):
    request.session.pop("user", None)
    return RedirectResponse(url="/")

build_ui(app)

from typing import Optional

from starlette.requests import Request
from app.settings import settings


def get_user_from_session(request: Request) -> Optional[dict]:
    return request.session.get("user")


def require_login(request: Request) -> dict:
    user = get_user_from_session(request)
    if not user:
        raise PermissionError("Not authenticated")
    return user


def allowed_groups() -> list[str]:
    raw = settings.OIDC_ALLOWED_GROUPS.strip()
    if not raw:
        return []
    return [g.strip() for g in raw.split(",") if g.strip()]


def user_has_access(user: dict) -> bool:
    allowed = set(allowed_groups())
    if not allowed:
        return True
    groups = set(user.get("groups", []))
    return len(groups.intersection(allowed)) > 0


def user_roles(user: dict) -> set[str]:
    groups = set(user.get("groups", []))
    roles = set()

    if "Capsule-IT" in groups:
        roles.add("it")
        roles.add("admin")
    if "Capsule-Management" in groups:
        roles.add("manager")
    if "Capsule-Production" in groups:
        roles.add("prod")

    if not roles:
        roles.add("viewer")

    return roles

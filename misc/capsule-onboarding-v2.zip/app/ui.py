import requests
from starlette.requests import Request
from nicegui import ui

from app.settings import settings
from app.security import get_user_from_session, user_has_access, user_roles
from app.actions.registry import list_actions as list_registered_actions


def api_get(path: str, cookies):
    return requests.get(f"{settings.PUBLIC_BASE_URL}{path}", cookies=cookies, timeout=10).json()


def api_post(path: str, cookies, payload: dict):
    return requests.post(f"{settings.PUBLIC_BASE_URL}{path}", cookies=cookies, json=payload, timeout=20).json()


def build_ui(fastapi_app):
    ui.run_with(fastapi_app)

    @ui.page("/")
    def dashboard(request: Request):
        user = get_user_from_session(request)
        if not user:
            ui.label("Not authenticated").classes("text-xl font-bold")
            ui.button("Login", on_click=lambda: ui.open("/auth/login"))
            return

        if not user_has_access(user):
            ui.label("Access denied (group restriction)").classes("text-xl font-bold")
            ui.button("Logout", on_click=lambda: ui.open("/auth/logout"))
            return

        roles = user_roles(user)

        with ui.row().classes("w-full items-center justify-between"):
            ui.label("🧩 Capsule Onboarding").classes("text-2xl font-bold")
            ui.label(f"{user.get('email')} • roles={','.join(sorted(roles))}").classes("text-sm opacity-70")
            ui.button("Logout", on_click=lambda: ui.open("/auth/logout")).props("outline")

        ui.separator()

        with ui.tabs().classes("w-full") as tabs:
            t_hires = ui.tab("Recrues")
            t_tasks = ui.tab("Tâches")
            t_actions = ui.tab("Actions")
            t_audit = ui.tab("Audit")

        with ui.tab_panels(tabs, value=t_hires).classes("w-full"):
            with ui.tab_panel(t_hires):
                hires_view(request)
            with ui.tab_panel(t_tasks):
                tasks_view(request)
            with ui.tab_panel(t_actions):
                actions_view(request)
            with ui.tab_panel(t_audit):
                audit_view(request)

    def hires_view(request: Request):
        ui.label("📋 Recrues").classes("text-lg font-semibold")

        with ui.card().classes("w-full"):
            with ui.row().classes("w-full gap-4"):
                full_name = ui.input("Nom complet").classes("w-1/4")
                personal_email = ui.input("Email").classes("w-1/4")
                team = ui.input("Team (FX/ANIM/PROD/...)").classes("w-1/6")
                role = ui.input("Role").classes("w-1/6")
                start_date = ui.date("Start date").classes("w-1/6")

            with ui.row().classes("w-full gap-4"):
                manager = ui.input("Manager (nom)").classes("w-1/3")
                buddy = ui.input("Buddy (nom)").classes("w-1/3")

                def create_hire():
                    payload = {
                        "full_name": full_name.value,
                        "personal_email": personal_email.value,
                        "team": (team.value or "UNKNOWN").upper(),
                        "role": (role.value or "UNKNOWN").upper(),
                        "start_date": start_date.value,
                        "manager_name": manager.value,
                        "buddy_name": buddy.value,
                    }
                    res = api_post("/api/hires", request.cookies, payload)
                    ui.notify(f"Recrue créée: {res.get('id')}", type="positive")
                    hires_table.refresh()

                ui.button("➕ Créer", on_click=create_hire).classes("w-48")

        class HiresTable:
            def __init__(self):
                self.table = None

            def refresh(self):
                rows = api_get("/api/hires", request.cookies)
                self.table.rows = rows
                self.table.update()

        hires_table = HiresTable()

        columns = [
            {"name": "id", "label": "ID", "field": "id"},
            {"name": "full_name", "label": "Nom", "field": "full_name"},
            {"name": "team", "label": "Team", "field": "team"},
            {"name": "role", "label": "Role", "field": "role"},
            {"name": "start_date", "label": "Start", "field": "start_date"},
            {"name": "status", "label": "Status", "field": "status"},
        ]
        rows = api_get("/api/hires", request.cookies)

        hires_table.table = ui.table(columns=columns, rows=rows, row_key="id").classes("w-full")
        ui.label("💡 Click sur un ID puis utilise l'onglet Tâches/Actions avec hire_id").classes("text-sm opacity-70")

    def tasks_view(request: Request):
        ui.label("✅ Tâches").classes("text-lg font-semibold")

        hire_id = ui.number("Filtre hire_id (optionnel)", value=None).props("clearable").classes("w-64")

        tasks_table = ui.table(
            columns=[
                {"name": "id", "label": "ID", "field": "id"},
                {"name": "hire_id", "label": "Hire", "field": "hire_id"},
                {"name": "title", "label": "Titre", "field": "title"},
                {"name": "owner", "label": "Owner", "field": "owner"},
                {"name": "status", "label": "Status", "field": "status"},
            ],
            rows=[],
            row_key="id",
        ).classes("w-full")

        def refresh():
            q = ""
            if hire_id.value:
                q = f"?hire_id={int(hire_id.value)}"
            rows = api_get(f"/api/tasks{q}", request.cookies)
            tasks_table.rows = rows
            tasks_table.update()

        ui.button("🔄 Refresh", on_click=refresh).props("outline")
        refresh()

    def actions_view(request: Request):
        ui.label("⚡ Actions").classes("text-lg font-semibold")

        with ui.row().classes("w-full gap-4"):
            hire_id = ui.number("hire_id", value=None).props("clearable").classes("w-48")
            action_key = ui.select(list_registered_actions(), label="action_key").classes("w-80")
            cmd = ui.input("payload.command (ex: echo hello)").classes("w-full")

        def create_action():
            if not hire_id.value:
                ui.notify("hire_id obligatoire", type="negative")
                return
            payload = {
                "hire_id": int(hire_id.value),
                "action_key": action_key.value,
                "payload": {"command": cmd.value, "stable_key": f"{hire_id.value}:{action_key.value}"},
            }
            res = api_post("/api/actions", request.cookies, payload)
            ui.notify(f"Action queued: {res.get('id')}", type="positive")
            refresh()

        ui.button("▶️ Run action", on_click=create_action).classes("w-48")

        actions_table = ui.table(
            columns=[
                {"name": "id", "label": "ID", "field": "id"},
                {"name": "hire_id", "label": "Hire", "field": "hire_id"},
                {"name": "action_key", "label": "Key", "field": "action_key"},
                {"name": "status", "label": "Status", "field": "status"},
                {"name": "retry_count", "label": "Retry", "field": "retry_count"},
                {"name": "created_at", "label": "Created", "field": "created_at"},
            ],
            rows=[],
            row_key="id",
        ).classes("w-full")

        def refresh():
            q = ""
            if hire_id.value:
                q = f"?hire_id={int(hire_id.value)}"
            rows = api_get(f"/api/actions{q}", request.cookies)
            actions_table.rows = rows
            actions_table.update()

        ui.button("🔄 Refresh actions", on_click=refresh).props("outline")
        refresh()

    def audit_view(request: Request):
        ui.label("🧾 Audit logs (last 200)").classes("text-lg font-semibold")
        rows = api_get("/api/audit", request.cookies)
        ui.table(
            columns=[
                {"name": "id", "label": "ID", "field": "id"},
                {"name": "created_at", "label": "Time", "field": "created_at"},
                {"name": "actor", "label": "Actor", "field": "actor"},
                {"name": "event", "label": "Event", "field": "event"},
                {"name": "target_type", "label": "Type", "field": "target_type"},
                {"name": "target_id", "label": "Target", "field": "target_id"},
                {"name": "meta_json", "label": "Meta", "field": "meta_json"},
            ],
            rows=rows,
            row_key="id",
        ).classes("w-full")

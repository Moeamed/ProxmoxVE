# Capsule Onboarding (V2 Prod)

## Run (Docker)
1) Copy env
```bash
cp .env.example .env
nano .env
```

2) Start
```bash
docker compose -f docker/docker-compose.yml up -d --build
```

3) Access
- Local: http://localhost:8088
- Prod via Caddy: https://onboarding.capsule.studio

## Caddy
Add:
```
onboarding.capsule.studio {
  reverse_proxy 127.0.0.1:8088
}
```

## OIDC (Authentik)
Create an OIDC application for onboarding and fill:
- OIDC_CLIENT_ID
- OIDC_CLIENT_SECRET
- OIDC_ISSUER_URL

Redirect URI:
- https://onboarding.capsule.studio/auth/callback

"""
OnboardFlow - Employee Onboarding Dashboard
A simple, self-hosted employee onboarding platform with account provisioning
"""

from fastapi import FastAPI, Request, HTTPException, Form, BackgroundTasks
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime, date
import sqlite3
import json
import os
import hashlib
import secrets

app = FastAPI(title="OnboardFlow", version="1.0.0")

# Mount static files and templates
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

DATABASE = "onboarding.db"

# ============== DATABASE ==============

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cursor = conn.cursor()
    
    # Employees table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            department TEXT,
            position TEXT,
            manager TEXT,
            start_date DATE,
            status TEXT DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Tasks templates table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS task_templates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            category TEXT,
            is_auto BOOLEAN DEFAULT 0,
            auto_script TEXT,
            order_num INTEGER DEFAULT 0
        )
    ''')
    
    # Employee tasks table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS employee_tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            task_template_id INTEGER,
            name TEXT NOT NULL,
            description TEXT,
            category TEXT,
            status TEXT DEFAULT 'pending',
            is_auto BOOLEAN DEFAULT 0,
            auto_script TEXT,
            completed_at TIMESTAMP,
            notes TEXT,
            FOREIGN KEY (employee_id) REFERENCES employees(id),
            FOREIGN KEY (task_template_id) REFERENCES task_templates(id)
        )
    ''')
    
    # Provisioning logs table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS provisioning_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            service TEXT NOT NULL,
            status TEXT NOT NULL,
            message TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (employee_id) REFERENCES employees(id)
        )
    ''')
    
    # Settings table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    ''')
    
    conn.commit()
    
    # Insert default task templates if empty
    cursor.execute('SELECT COUNT(*) FROM task_templates')
    if cursor.fetchone()[0] == 0:
        default_tasks = [
            ('Créer compte Google Workspace', 'Créer le compte email professionnel', 'IT', 1, 'google_workspace', 1),
            ('Créer compte Slack', 'Ajouter au workspace Slack', 'IT', 1, 'slack', 2),
            ('Créer compte GitHub', 'Ajouter à l\'organisation GitHub', 'IT', 1, 'github', 3),
            ('Préparer le poste de travail', 'Configurer l\'ordinateur et les accès', 'IT', 0, None, 4),
            ('Créer badge d\'accès', 'Demander le badge auprès de la sécurité', 'Admin', 0, None, 5),
            ('Envoyer welcome pack', 'Envoyer le kit de bienvenue', 'RH', 0, None, 6),
            ('Planifier réunion d\'intégration', 'Organiser le meeting avec l\'équipe', 'RH', 0, None, 7),
            ('Formation sécurité', 'Compléter la formation sécurité obligatoire', 'Formation', 0, None, 8),
            ('Signature contrat', 'Faire signer tous les documents', 'RH', 0, None, 9),
            ('Tour des locaux', 'Présenter les locaux et l\'équipe', 'RH', 0, None, 10),
        ]
        cursor.executemany('''
            INSERT INTO task_templates (name, description, category, is_auto, auto_script, order_num)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', default_tasks)
        conn.commit()
    
    conn.close()

init_db()

# ============== MODELS ==============

class EmployeeCreate(BaseModel):
    first_name: str
    last_name: str
    email: EmailStr
    department: Optional[str] = None
    position: Optional[str] = None
    manager: Optional[str] = None
    start_date: Optional[date] = None

class TaskUpdate(BaseModel):
    status: str
    notes: Optional[str] = None

# ============== ROUTES ==============

@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    conn = get_db()
    cursor = conn.cursor()
    
    # Get statistics
    cursor.execute('SELECT COUNT(*) FROM employees')
    total_employees = cursor.fetchone()[0]
    
    cursor.execute('SELECT COUNT(*) FROM employees WHERE status = "pending"')
    pending = cursor.fetchone()[0]
    
    cursor.execute('SELECT COUNT(*) FROM employees WHERE status = "in_progress"')
    in_progress = cursor.fetchone()[0]
    
    cursor.execute('SELECT COUNT(*) FROM employees WHERE status = "completed"')
    completed = cursor.fetchone()[0]
    
    # Get recent employees
    cursor.execute('''
        SELECT e.*, 
               (SELECT COUNT(*) FROM employee_tasks WHERE employee_id = e.id AND status = 'completed') as tasks_done,
               (SELECT COUNT(*) FROM employee_tasks WHERE employee_id = e.id) as tasks_total
        FROM employees e 
        ORDER BY created_at DESC 
        LIMIT 10
    ''')
    employees = cursor.fetchall()
    
    # Get task completion rate
    cursor.execute('SELECT COUNT(*) FROM employee_tasks')
    total_tasks = cursor.fetchone()[0]
    cursor.execute('SELECT COUNT(*) FROM employee_tasks WHERE status = "completed"')
    completed_tasks = cursor.fetchone()[0]
    completion_rate = int((completed_tasks / total_tasks * 100) if total_tasks > 0 else 0)
    
    conn.close()
    
    return templates.TemplateResponse("dashboard.html", {
        "request": request,
        "total_employees": total_employees,
        "pending": pending,
        "in_progress": in_progress,
        "completed": completed,
        "employees": employees,
        "completion_rate": completion_rate
    })

@app.get("/employees", response_class=HTMLResponse)
async def list_employees(request: Request):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT e.*, 
               (SELECT COUNT(*) FROM employee_tasks WHERE employee_id = e.id AND status = 'completed') as tasks_done,
               (SELECT COUNT(*) FROM employee_tasks WHERE employee_id = e.id) as tasks_total
        FROM employees e 
        ORDER BY created_at DESC
    ''')
    employees = cursor.fetchall()
    conn.close()
    
    return templates.TemplateResponse("employees.html", {
        "request": request,
        "employees": employees
    })

@app.get("/employees/new", response_class=HTMLResponse)
async def new_employee_form(request: Request):
    return templates.TemplateResponse("employee_form.html", {
        "request": request,
        "employee": None
    })

@app.post("/employees")
async def create_employee(
    request: Request,
    first_name: str = Form(...),
    last_name: str = Form(...),
    email: str = Form(...),
    department: str = Form(None),
    position: str = Form(None),
    manager: str = Form(None),
    start_date: str = Form(None)
):
    conn = get_db()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            INSERT INTO employees (first_name, last_name, email, department, position, manager, start_date, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')
        ''', (first_name, last_name, email, department, position, manager, start_date or None))
        
        employee_id = cursor.lastrowid
        
        # Create tasks from templates
        cursor.execute('SELECT * FROM task_templates ORDER BY order_num')
        templates_list = cursor.fetchall()
        
        for t in templates_list:
            cursor.execute('''
                INSERT INTO employee_tasks (employee_id, task_template_id, name, description, category, is_auto, auto_script, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')
            ''', (employee_id, t['id'], t['name'], t['description'], t['category'], t['is_auto'], t['auto_script']))
        
        conn.commit()
        conn.close()
        
        return RedirectResponse(url=f"/employees/{employee_id}", status_code=303)
    
    except sqlite3.IntegrityError:
        conn.close()
        return templates.TemplateResponse("employee_form.html", {
            "request": request,
            "employee": None,
            "error": "Cet email existe déjà"
        })

@app.get("/employees/{employee_id}", response_class=HTMLResponse)
async def view_employee(request: Request, employee_id: int):
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM employees WHERE id = ?', (employee_id,))
    employee = cursor.fetchone()
    
    if not employee:
        raise HTTPException(status_code=404, detail="Employé non trouvé")
    
    cursor.execute('''
        SELECT * FROM employee_tasks 
        WHERE employee_id = ? 
        ORDER BY 
            CASE status 
                WHEN 'pending' THEN 1 
                WHEN 'in_progress' THEN 2 
                WHEN 'completed' THEN 3 
            END,
            id
    ''', (employee_id,))
    tasks = cursor.fetchall()
    
    cursor.execute('''
        SELECT * FROM provisioning_logs 
        WHERE employee_id = ? 
        ORDER BY created_at DESC
    ''', (employee_id,))
    logs = cursor.fetchall()
    
    conn.close()
    
    return templates.TemplateResponse("employee_detail.html", {
        "request": request,
        "employee": employee,
        "tasks": tasks,
        "logs": logs
    })

@app.post("/employees/{employee_id}/tasks/{task_id}/toggle")
async def toggle_task(employee_id: int, task_id: int):
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT status FROM employee_tasks WHERE id = ? AND employee_id = ?', (task_id, employee_id))
    task = cursor.fetchone()
    
    if not task:
        conn.close()
        raise HTTPException(status_code=404, detail="Tâche non trouvée")
    
    new_status = 'completed' if task['status'] != 'completed' else 'pending'
    completed_at = datetime.now().isoformat() if new_status == 'completed' else None
    
    cursor.execute('''
        UPDATE employee_tasks 
        SET status = ?, completed_at = ?
        WHERE id = ?
    ''', (new_status, completed_at, task_id))
    
    # Update employee status
    cursor.execute('SELECT COUNT(*) FROM employee_tasks WHERE employee_id = ?', (employee_id,))
    total = cursor.fetchone()[0]
    cursor.execute('SELECT COUNT(*) FROM employee_tasks WHERE employee_id = ? AND status = "completed"', (employee_id,))
    done = cursor.fetchone()[0]
    
    if done == 0:
        emp_status = 'pending'
    elif done == total:
        emp_status = 'completed'
    else:
        emp_status = 'in_progress'
    
    cursor.execute('UPDATE employees SET status = ?, updated_at = ? WHERE id = ?', 
                   (emp_status, datetime.now().isoformat(), employee_id))
    
    conn.commit()
    conn.close()
    
    return JSONResponse({"status": new_status, "employee_status": emp_status})

@app.post("/employees/{employee_id}/provision/{service}")
async def provision_service(employee_id: int, service: str, background_tasks: BackgroundTasks):
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM employees WHERE id = ?', (employee_id,))
    employee = cursor.fetchone()
    
    if not employee:
        conn.close()
        raise HTTPException(status_code=404, detail="Employé non trouvé")
    
    # Log the provisioning attempt
    cursor.execute('''
        INSERT INTO provisioning_logs (employee_id, service, status, message)
        VALUES (?, ?, 'pending', 'Provisioning en cours...')
    ''', (employee_id, service))
    log_id = cursor.lastrowid
    conn.commit()
    conn.close()
    
    # Run provisioning in background
    background_tasks.add_task(run_provisioning, employee_id, service, log_id, dict(employee))
    
    return JSONResponse({"status": "started", "log_id": log_id})

async def run_provisioning(employee_id: int, service: str, log_id: int, employee: dict):
    """Execute provisioning script"""
    from scripts.provisioning import provision_account
    
    try:
        result = await provision_account(service, employee)
        status = 'success' if result['success'] else 'error'
        message = result.get('message', 'Terminé')
    except Exception as e:
        status = 'error'
        message = str(e)
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        UPDATE provisioning_logs 
        SET status = ?, message = ?
        WHERE id = ?
    ''', (status, message, log_id))
    
    # Update task if successful
    if status == 'success':
        cursor.execute('''
            UPDATE employee_tasks 
            SET status = 'completed', completed_at = ?
            WHERE employee_id = ? AND auto_script = ?
        ''', (datetime.now().isoformat(), employee_id, service))
    
    conn.commit()
    conn.close()

@app.delete("/employees/{employee_id}")
async def delete_employee(employee_id: int):
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('DELETE FROM employee_tasks WHERE employee_id = ?', (employee_id,))
    cursor.execute('DELETE FROM provisioning_logs WHERE employee_id = ?', (employee_id,))
    cursor.execute('DELETE FROM employees WHERE id = ?', (employee_id,))
    
    conn.commit()
    conn.close()
    
    return JSONResponse({"status": "deleted"})

@app.get("/settings", response_class=HTMLResponse)
async def settings_page(request: Request):
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM task_templates ORDER BY order_num')
    templates_list = cursor.fetchall()
    
    cursor.execute('SELECT * FROM settings')
    settings = {row['key']: row['value'] for row in cursor.fetchall()}
    
    conn.close()
    
    return templates.TemplateResponse("settings.html", {
        "request": request,
        "templates": templates_list,
        "settings": settings
    })

@app.post("/settings/tasks")
async def add_task_template(
    name: str = Form(...),
    description: str = Form(None),
    category: str = Form(None),
    is_auto: bool = Form(False),
    auto_script: str = Form(None)
):
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT MAX(order_num) FROM task_templates')
    max_order = cursor.fetchone()[0] or 0
    
    cursor.execute('''
        INSERT INTO task_templates (name, description, category, is_auto, auto_script, order_num)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (name, description, category, 1 if is_auto else 0, auto_script if is_auto else None, max_order + 1))
    
    conn.commit()
    conn.close()
    
    return RedirectResponse(url="/settings", status_code=303)

@app.delete("/settings/tasks/{task_id}")
async def delete_task_template(task_id: int):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM task_templates WHERE id = ?', (task_id,))
    conn.commit()
    conn.close()
    
    return JSONResponse({"status": "deleted"})

@app.post("/settings/api")
async def save_api_settings(
    google_credentials: str = Form(None),
    slack_token: str = Form(None),
    github_token: str = Form(None)
):
    conn = get_db()
    cursor = conn.cursor()
    
    settings = [
        ('google_credentials', google_credentials),
        ('slack_token', slack_token),
        ('github_token', github_token)
    ]
    
    for key, value in settings:
        if value:
            cursor.execute('''
                INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)
            ''', (key, value))
    
    conn.commit()
    conn.close()
    
    return RedirectResponse(url="/settings", status_code=303)

# API endpoints for external integrations
@app.get("/api/employees")
async def api_list_employees():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM employees ORDER BY created_at DESC')
    employees = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return employees

@app.get("/api/employees/{employee_id}")
async def api_get_employee(employee_id: int):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM employees WHERE id = ?', (employee_id,))
    employee = cursor.fetchone()
    if not employee:
        raise HTTPException(status_code=404)
    
    cursor.execute('SELECT * FROM employee_tasks WHERE employee_id = ?', (employee_id,))
    tasks = [dict(row) for row in cursor.fetchall()]
    
    conn.close()
    return {"employee": dict(employee), "tasks": tasks}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

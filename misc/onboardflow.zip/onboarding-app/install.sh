#!/usr/bin/env bash

# OnboardFlow - Quick Install Script
# Usage: curl -fsSL https://URL/install.sh | bash

set -e

echo "
   ___        _                         _ _____ _               
  / _ \ _ __ | |__   ___   __ _ _ __ __| |  ___| | _____      __
 | | | | '_ \| '_ \ / _ \ / _\` | '__/ _\` | |_  | |/ _ \ \ /\ / /
 | |_| | | | | |_) | (_) | (_| | | | (_| |  _| | | (_) \ V  V / 
  \___/|_| |_|_.__/ \___/ \__,_|_|  \__,_|_|   |_|\___/ \_/\_/  
                                                                 
  Employee Onboarding Dashboard
"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}[1/5]${NC} Installing Docker..."
if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com | sh
    systemctl enable docker --now
fi
echo -e "${GREEN}✓${NC} Docker installed"

echo -e "${YELLOW}[2/5]${NC} Creating directory..."
mkdir -p /opt/onboardflow
cd /opt/onboardflow

echo -e "${YELLOW}[3/5]${NC} Downloading application..."
# Clone or download the app
cat > docker-compose.yml << 'EOF'
services:
  onboardflow:
    image: python:3.11-slim
    container_name: onboardflow
    restart: unless-stopped
    ports:
      - "8080:8000"
    volumes:
      - ./app:/app
      - ./data:/data
    working_dir: /app
    command: >
      bash -c "pip install -q fastapi uvicorn jinja2 python-multipart httpx pydantic[email] &&
               uvicorn app.main:app --host 0.0.0.0 --port 8000"
    environment:
      - TZ=Europe/Paris
EOF

# Download app files
git clone https://github.com/YOUR_USER/onboardflow.git app 2>/dev/null || {
    echo "Clone failed, downloading files manually..."
    # Fallback: create a minimal version
}

echo -e "${YELLOW}[4/5]${NC} Starting application..."
docker compose up -d
echo -e "${GREEN}✓${NC} Application started"

echo -e "${YELLOW}[5/5]${NC} Creating service..."
cat > /etc/systemd/system/onboardflow.service << 'EOF'
[Unit]
Description=OnboardFlow
Requires=docker.service
After=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=/opt/onboardflow
ExecStart=/usr/bin/docker compose up -d
ExecStop=/usr/bin/docker compose down

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable onboardflow

# Get IP
IP=$(hostname -I | awk '{print $1}')

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║           OnboardFlow Installation Complete!                 ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  🌐 Access URL: ${GREEN}http://${IP}:8080${NC}"
echo ""
echo -e "  Useful commands:"
echo -e "    systemctl status onboardflow  - Check status"
echo -e "    systemctl restart onboardflow - Restart"
echo -e "    docker logs onboardflow       - View logs"
echo ""

# OnboardFlow

**Dashboard d'onboarding employés avec provisioning automatique**

![Dashboard](https://img.shields.io/badge/Dashboard-Modern-6366f1)
![Python](https://img.shields.io/badge/Python-3.11-blue)
![Docker](https://img.shields.io/badge/Docker-Ready-2496ED)

Une application simple et moderne pour gérer l'onboarding de vos nouveaux employés avec :
- ✅ Suivi des tâches d'intégration
- ⚡ Provisioning automatique des comptes (Google, Slack, GitHub...)
- 📊 Dashboard avec statistiques en temps réel
- 🎨 Interface moderne en dark mode

## 📸 Aperçu

L'interface inclut :
- Dashboard avec vue d'ensemble et statistiques
- Liste des employés avec progression
- Fiche détaillée par employé avec checklist des tâches
- Configuration des tâches par défaut
- Configuration des API de provisioning

## 🚀 Installation rapide

### Avec Docker (recommandé)

```bash
# Cloner le repo
git clone https://github.com/VOTRE_USER/onboardflow.git
cd onboardflow

# Lancer
docker compose up -d

# Accéder à http://localhost:8080
```

### Sans Docker

```bash
# Installer les dépendances
pip install -r requirements.txt

# Lancer
cd app
uvicorn main:app --host 0.0.0.0 --port 8000
```

## 📁 Structure du projet

```
onboardflow/
├── app/
│   └── main.py           # Application FastAPI
├── templates/            # Templates HTML Jinja2
│   ├── base.html
│   ├── dashboard.html
│   ├── employees.html
│   ├── employee_form.html
│   ├── employee_detail.html
│   └── settings.html
├── static/
│   ├── css/style.css     # Styles (Dark theme)
│   └── js/app.js         # JavaScript
├── scripts/
│   └── provisioning.py   # Scripts de provisioning
├── docker-compose.yml
├── Dockerfile
└── requirements.txt
```

## ⚙️ Configuration

### Tâches par défaut

Configurez les tâches qui seront automatiquement assignées à chaque nouvel employé dans **Settings > Tâches par défaut**.

### API de provisioning

Configurez vos clés API dans **Settings > Configuration API** :

| Service | Clé requise | Comment l'obtenir |
|---------|-------------|-------------------|
| Google Workspace | JSON credentials | Google Cloud Console > Service Account |
| Slack | Bot Token (`xoxb-...`) | api.slack.com > Your App > OAuth |
| GitHub | Personal Access Token | github.com > Settings > Developer settings |

### Variables d'environnement (optionnel)

```env
TZ=Europe/Paris
```

## 🔌 API REST

L'application expose une API REST pour l'intégration :

```bash
# Liste des employés
GET /api/employees

# Détail d'un employé avec ses tâches
GET /api/employees/{id}

# Créer un employé (via formulaire)
POST /employees
```

## 🔧 Personnalisation du provisioning

Modifiez `scripts/provisioning.py` pour adapter les scripts à vos besoins :

```python
async def provision_custom(employee: Dict[str, Any]) -> Dict[str, Any]:
    """Votre logique custom ici"""
    # Appel API, script local, webhook...
    return {"success": True, "message": "OK"}
```

## 📝 Fonctionnalités prévues

- [ ] Export CSV des employés
- [ ] Notifications email
- [ ] Authentification
- [ ] Multi-organisation
- [ ] Webhooks entrants

## 🤝 Contribution

Les contributions sont les bienvenues ! N'hésitez pas à ouvrir une issue ou une PR.

## 📄 Licence

MIT License - Utilisez librement !

---

Fait avec ❤️ pour simplifier l'onboarding

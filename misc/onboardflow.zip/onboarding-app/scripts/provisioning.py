"""
Provisioning Scripts for OnboardFlow
Add your API credentials and customize these functions
"""

import os
import json
import httpx
import sqlite3
from typing import Dict, Any

DATABASE = "onboarding.db"

def get_setting(key: str) -> str:
    """Get setting from database"""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('SELECT value FROM settings WHERE key = ?', (key,))
    result = cursor.fetchone()
    conn.close()
    return result[0] if result else None


async def provision_account(service: str, employee: Dict[str, Any]) -> Dict[str, Any]:
    """
    Main provisioning function - routes to specific service
    """
    provisioners = {
        'google_workspace': provision_google_workspace,
        'slack': provision_slack,
        'github': provision_github,
        'microsoft365': provision_microsoft365,
        'custom': provision_custom,
    }
    
    if service not in provisioners:
        return {"success": False, "message": f"Service '{service}' non supporté"}
    
    return await provisioners[service](employee)


async def provision_google_workspace(employee: Dict[str, Any]) -> Dict[str, Any]:
    """
    Create Google Workspace account
    Requires: Google Admin SDK credentials
    """
    credentials = get_setting('google_credentials')
    
    if not credentials:
        return {
            "success": False, 
            "message": "Credentials Google non configurés. Allez dans Settings > API Keys"
        }
    
    try:
        # Example implementation - customize for your setup
        # You'll need to set up Google Admin SDK
        
        email = employee['email']
        first_name = employee['first_name']
        last_name = employee['last_name']
        
        # Placeholder - implement actual Google API call
        # from google.oauth2 import service_account
        # from googleapiclient.discovery import build
        
        return {
            "success": True,
            "message": f"Compte Google créé pour {email}",
            "data": {"email": email}
        }
        
    except Exception as e:
        return {"success": False, "message": str(e)}


async def provision_slack(employee: Dict[str, Any]) -> Dict[str, Any]:
    """
    Invite user to Slack workspace
    Requires: Slack Bot Token with admin.users:write scope
    """
    token = get_setting('slack_token')
    
    if not token:
        return {
            "success": False,
            "message": "Token Slack non configuré. Allez dans Settings > API Keys"
        }
    
    try:
        email = employee['email']
        
        async with httpx.AsyncClient() as client:
            # Invite user to workspace
            response = await client.post(
                "https://slack.com/api/admin.users.invite",
                headers={
                    "Authorization": f"Bearer {token}",
                    "Content-Type": "application/json"
                },
                json={
                    "email": email,
                    "team_id": get_setting('slack_team_id'),  # Your workspace ID
                    "channel_ids": get_setting('slack_default_channels') or "",
                }
            )
            
            data = response.json()
            
            if data.get('ok'):
                return {
                    "success": True,
                    "message": f"Invitation Slack envoyée à {email}"
                }
            else:
                # Try regular invite as fallback
                response = await client.post(
                    "https://slack.com/api/users.admin.invite",
                    headers={"Authorization": f"Bearer {token}"},
                    data={"email": email}
                )
                data = response.json()
                
                if data.get('ok'):
                    return {"success": True, "message": f"Invitation Slack envoyée à {email}"}
                else:
                    return {"success": False, "message": data.get('error', 'Erreur inconnue')}
                    
    except Exception as e:
        return {"success": False, "message": str(e)}


async def provision_github(employee: Dict[str, Any]) -> Dict[str, Any]:
    """
    Add user to GitHub organization
    Requires: GitHub Personal Access Token with admin:org scope
    """
    token = get_setting('github_token')
    org = get_setting('github_org')
    
    if not token:
        return {
            "success": False,
            "message": "Token GitHub non configuré. Allez dans Settings > API Keys"
        }
    
    if not org:
        return {
            "success": False,
            "message": "Organisation GitHub non configurée"
        }
    
    try:
        email = employee['email']
        
        async with httpx.AsyncClient() as client:
            # Invite user to organization
            response = await client.post(
                f"https://api.github.com/orgs/{org}/invitations",
                headers={
                    "Authorization": f"Bearer {token}",
                    "Accept": "application/vnd.github+json",
                    "X-GitHub-Api-Version": "2022-11-28"
                },
                json={
                    "email": email,
                    "role": "direct_member"
                }
            )
            
            if response.status_code in [200, 201]:
                return {
                    "success": True,
                    "message": f"Invitation GitHub envoyée à {email}"
                }
            else:
                data = response.json()
                return {
                    "success": False,
                    "message": data.get('message', f'Erreur {response.status_code}')
                }
                
    except Exception as e:
        return {"success": False, "message": str(e)}


async def provision_microsoft365(employee: Dict[str, Any]) -> Dict[str, Any]:
    """
    Create Microsoft 365 account
    Requires: Microsoft Graph API credentials
    """
    # Placeholder - implement Microsoft Graph API
    return {
        "success": False,
        "message": "Microsoft 365 provisioning pas encore implémenté. Configurez l'API Graph."
    }


async def provision_custom(employee: Dict[str, Any]) -> Dict[str, Any]:
    """
    Custom provisioning - add your own logic here
    """
    # Example: Call a custom webhook
    webhook_url = get_setting('custom_webhook_url')
    
    if not webhook_url:
        return {
            "success": False,
            "message": "Webhook URL non configuré"
        }
    
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                webhook_url,
                json={
                    "action": "create_user",
                    "employee": {
                        "email": employee['email'],
                        "first_name": employee['first_name'],
                        "last_name": employee['last_name'],
                        "department": employee.get('department'),
                        "position": employee.get('position'),
                    }
                }
            )
            
            if response.status_code == 200:
                return {"success": True, "message": "Webhook exécuté avec succès"}
            else:
                return {"success": False, "message": f"Erreur webhook: {response.status_code}"}
                
    except Exception as e:
        return {"success": False, "message": str(e)}


# ============== CLI PROVISIONING ==============

async def provision_all_services(employee_id: int):
    """
    Provision all auto services for an employee
    Can be called from CLI or scheduled task
    """
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM employees WHERE id = ?', (employee_id,))
    employee = cursor.fetchone()
    
    if not employee:
        print(f"Employee {employee_id} not found")
        return
    
    cursor.execute('''
        SELECT DISTINCT auto_script FROM employee_tasks 
        WHERE employee_id = ? AND is_auto = 1 AND status != 'completed'
    ''', (employee_id,))
    
    services = [row['auto_script'] for row in cursor.fetchall() if row['auto_script']]
    
    results = {}
    for service in services:
        print(f"Provisioning {service} for {employee['email']}...")
        result = await provision_account(service, dict(employee))
        results[service] = result
        print(f"  -> {result['message']}")
    
    conn.close()
    return results


if __name__ == "__main__":
    import asyncio
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python provisioning.py <employee_id> [service]")
        sys.exit(1)
    
    employee_id = int(sys.argv[1])
    
    if len(sys.argv) > 2:
        service = sys.argv[2]
        conn = sqlite3.connect(DATABASE)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM employees WHERE id = ?', (employee_id,))
        employee = cursor.fetchone()
        conn.close()
        
        if employee:
            result = asyncio.run(provision_account(service, dict(employee)))
            print(result)
    else:
        asyncio.run(provision_all_services(employee_id))
